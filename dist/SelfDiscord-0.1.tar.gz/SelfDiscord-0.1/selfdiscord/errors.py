class InvalidToken(Exception):
    pass

class Forbidden(Exception):
    pass

class BadRequest(Exception):
    pass

class NotFound(Exception):
    pass

#Made By RedBall